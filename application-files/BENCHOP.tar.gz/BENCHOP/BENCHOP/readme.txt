Run Table.m to execute all of the methods presented in the surrounding folders and generate a latex table as an output.
